## **************** Hackathon ******************** ##

library(lubridate)
library(rucm)

# Loading the data
store_data <- read.csv("C:/Users/sbhur/Documents/Hackathon/superstore.csv")


## Treatment of "Order date" column
ymd <- ymd(store_data$Order.Date) 
dmy <- dmy(store_data$Order.Date) 
ymd[is.na(ymd)] <- dmy[is.na(ymd)]  
store_data$Order.Date <- ymd       


## Treatment of "Ship date" column
ymd1 <- ymd(store_data$Ship.Date) 
dmy1 <- dmy(store_data$Ship.Date) 
ymd1[is.na(ymd1)] <- dmy1[is.na(ymd1)]  
store_data$Ship.Date <- ymd1       


## Replacing dot(.) with underscore(_) from column names 
colnames(store_data) <- gsub('\\.', '_' ,colnames(store_data))


## Minimum and Maximum date of Order and Ship date
min(store_data$Order_Date); max(store_data$Order_Date)
min(store_data$Ship_Date); max(store_data$Ship_Date)


write.csv(store_data, "C:/Users/sbhur/Documents/Hackathon/superstore_cleaned.csv")

## Cleaning space
rm(store_data)
rm(dmy); rm(dmy1); rm(ymd); rm(ymd1)


# Re-Loading the cleaned data
store_data_clnd <- read.csv("C:/Users/sbhur/Documents/Hackathon/superstore_cleaned.csv")
store_data_clnd <- unique(store_data_clnd)

store_data_clnd$Order_Date <- as.Date(store_data_clnd$Order_Date, format = "%m/%d/%Y")
store_data_clnd$Ship_Date <- as.Date(store_data_clnd$Ship_Date, format = "%m/%d/%Y")


## Data series
order_date_series <- data.frame(Order_Date = seq(as.Date(min(store_data_clnd$Order_Date)), as.Date(max(store_data_clnd$Order_Date)), by = "1 day"))
# ship_date_series <- seq(as.Date(min(store_data_clnd$Ship_Date)), as.Date(max(store_data_clnd$Ship_Date)), by = "1 day")

store_data_clnd$date_diff <- store_data_clnd$Ship_Date - store_data_clnd$Order_Date
table(store_data_clnd$date_diff < 0)


## Merging with all the dates to check missing values
store_data_clnd_1 <- merge(order_date_series, store_data_clnd, by = "Order_Date", all.x = TRUE)


## Final data
final_data <- unique(store_data_clnd_1[, c("Order_Date", "Order_ID", 
                                           "Customer_ID", "Product_ID",
                                           "Sales")])

# write.csv(final_data, "C:/Users/sbhur/Documents/Hackathon/For_EDA.csv", row.names = F)


## Missing Value Treatment of each columns
colSums(is.na(final_data))

final_data$Order_ID <- ifelse(is.na(final_data$Order_ID), "Not_Available", final_data$Order_ID)
final_data$Customer_ID <- ifelse(is.na(final_data$Customer_ID), "Not_Available", final_data$Customer_ID)
final_data$Product_ID <- ifelse(is.na(final_data$Product_ID), "Not_Available", final_data$Product_ID)
final_data$Sales <- ifelse(is.na(final_data$Sales), 0, final_data$Sales)


## Combining Order_ID, Customer_ID, Product_ID 
final_data$OrderCustProdID <- 
  paste(final_data$Order_ID, final_data$Customer_ID, final_data$Product_ID,
        sep = "_") 


# data_qty <- final_data[,5] # Actual Qty column
# data_ts <- ts(data_qty, frequency = 365)


## Train and Test
trn_data <- final_data[!year(final_data$Order_Date) %in% "2017",]
tst_data <- final_data[year(final_data$Order_Date) %in% "2017",]


data_qty <- trn_data[,5] # Actual Qty column
data_ts <- ts(data_qty, frequency = 365)



## ETS Model
ets_model <- ets(trn_data$Sales, model = "ZZZ")

# Forecast
ets_forecast <- forecast(ets_model, nrow(tst_data))


frcst_ets = cbind.data.frame(Order_Date = tst_data$Order_Date,
                                Order_ID = tst_data$Order_ID,
                                Customer_ID = tst_data$Customer_ID,
                                Product_ID = tst_data$Product_ID,
                                OrderCustProdID = tst_data$OrderCustProdID,
                                Actuals = tst_data$Sales,
                                Forecasted = pmax(as.numeric(ets_forecast$mean), 0),
                                Upper_Values = ets_forecast$upper,
                                Lower_Values = ets_forecast$lower,
                                stringsAsFactors=FALSE)

frcst_ets$AbsDev <- abs(frcst_ets$Actuals - frcst_ets$Forecasted)

write.csv(frcst_ets, "C:/Users/sbhur/Documents/Hackathon/Final_ETS_Model_Output.csv", row.names = F)


